import pandas as pd 
from sqlalchemy import create_engine 
engine = create_engine('sqlite:///pak-and-egypt-used-and-new.db', echo=True) 
df = pd.read_csv("all_csvs.csv") 
df.to_sql('users', con=engine, index=False)