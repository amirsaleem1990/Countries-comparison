rm -rf all_csvs.csv
for i in $(find . -name *.csv); do cat $i >> all_csvs.csv; done
echo "********************



final csv contains: " ; wc -l all_csvs.csv; echo "



********************"
python3 csv-to-db.py
