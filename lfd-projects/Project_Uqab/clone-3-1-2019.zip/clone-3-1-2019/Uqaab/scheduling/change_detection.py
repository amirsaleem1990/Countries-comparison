import pandas as pd
import sqlalchemy as sa
import json
import difflib
import datetime
import logging

from environment import config
from emailer import send_error_email
from loggers import create_logging_file


CONNECTION_STRING = config('SA_CONNECTION_STRING')
logging = create_logging_file()


class ChangeDetection():
    THRESHOLD = 0.75

    def __init__(self, db_connection, list_id, new_sublist_id, old_sublist_id, program_name):
        self.conn = db_connection
        self.list_id = list_id
        self.new_sublist_id = new_sublist_id
        self.old_sublist_id = old_sublist_id
        self.ExistingTable = None
        self.ScrapedTable = None
        self.source_df = None
        self.target_df = None
        self.program_name = program_name

    def detect(self):
        self._create_dataframes()
        if self._data_has_changes():
            self._enable_new_version()
            self._copy_data('tbl_entities', 'tbl_scrappedData')
            changes, value_changes = self._identify_changes()
            self._record_modifications(changes, value_changes)
            return True
        else:
            self._delete_new_version()
            return False

    def _create_dataframes(self):
        if self.old_sublist_id is not None:
            self._create_df_from_except_queries()
        else:
            self._create_df_from_select_query()

        self.source_df = self.ScrapedTable.copy()
        self.target_df = self.ExistingTable.copy()

    def _create_df_from_except_queries(self):

        NEW_RECORDS_QUERY = "SELECT Name, DOB, Aliases, Remarks, Title, DO_Inclusion from tbl_entities WHERE SubListID = ? EXCEPT SELECT Name, DOB, Aliases, Remarks, Title, DO_Inclusion from tbl_scrappedData WHERE SubListID = ?;"
        OLD_RECORDS_QUERY = "SELECT Name, DOB, Aliases, Remarks, Title, DO_Inclusion from tbl_scrappedData WHERE SubListID = ? EXCEPT SELECT Name, DOB, Aliases, Remarks, Title, DO_Inclusion from tbl_entities WHERE SubListID = ?;"

        self.ExistingTable = self._make_df_from_query(NEW_RECORDS_QUERY, (self.new_sublist_id, self.old_sublist_id))
        self.ScrapedTable = self._make_df_from_query(OLD_RECORDS_QUERY, (self.old_sublist_id, self.new_sublist_id))

    def _create_df_from_select_query(self):
        NEW_RECORDS_QUERY = "SELECT Name, DOB, Aliases, Remarks, Title, DO_Inclusion from tbl_entities WHERE SubListID = ?;"

        self.ExistingTable = self._make_df_from_query(NEW_RECORDS_QUERY, (self.new_sublist_id))
        self.ScrapedTable = pd.DataFrame()

    def _make_df_from_query(self, query, values):
        results = self._execute_query(query, values)
        df = pd.DataFrame(results.fetchall())

        try:
            df.columns = results.keys()
        except ValueError:
            pass
        return df

    def _data_has_changes(self):
        return len(self.ExistingTable.index) > 0 or len(self.ScrapedTable.index) > 0

    def _copy_data(self, source, destination):
        COPY_QUERY = """INSERT INTO {destination} (EDateTime, SubListID, ECategory, Name, Address, DOB, Nationality, Designation, Organization, Title, DO_Inclusion, DO_Exclusion, Aliases, Matching, ListType, Remarks, Status, Gender, Last_Occupation, Documents) SELECT EDateTime, SubListID, ECategory, Name, Address, DOB, Nationality, Designation, Organization, Title, DO_Inclusion, DO_Exclusion, Aliases, Matching, ListType, Remarks, Status, Gender, Last_Occupation, Documents FROM {source} WHERE SubListID = ?;"""
        self._execute_query(COPY_QUERY.format(source=source, destination=destination), (self.new_sublist_id,))

    def _delete_new_version(self):
        if self.old_sublist_id is not None:
            self._execute_query("Update tbl_entities SET SubListID = ? WHERE SubListID = ?",
                                (self.old_sublist_id, self.new_sublist_id))
            self._execute_query("DELETE FROM tbl_subwatchlist where SubListID = ?", (self.new_sublist_id))

    def _enable_new_version(self):
        self._execute_query("Update tbl_subwatchlist SET IsEnabled = ? WHERE SubListID = ?", (1, self.new_sublist_id))

    def _execute_query(self, query, values=None):
        if values:
            return self.conn.execute(query, values)
        return self.conn.execute(query)

    def _identify_changes(self):
        logging.info("Start Identifying the changes for {}".format(self.program_name))
        changes = {}
        value_change = {}

        for sindex, srow in self.source_df.iterrows():
            sname = self._clean_string(srow["Name"], ['name',])
            sdob = self._clean_string(srow["DOB"], ['00:00:00', '"DOB"', '"POB"', 'null'])
            stitle = self._clean_string(srow["Title"], ['title',])
            sremarks = srow["Remarks"] if srow["Remarks"] else ""
            sAliases = self._clean_string(srow["Aliases"], ['Aliases',])
            sdateinc = srow["DO_Inclusion"] if srow["DO_Inclusion"] else ""

            for tindex, trow in self.target_df.iterrows():
                tname = self._clean_string(trow["Name"], ['name',])
                tdob = self._clean_string(trow["DOB"], ['00:00:00', '"DOB"', '"POB"', 'null'])
                ttitle = self._clean_string(trow["Title"], ['title',])
                tremarks = trow["Remarks"] if trow["Remarks"] else ""
                tAliases = self._clean_string(trow["Aliases"], ['Aliases',])
                tdateinc = trow["DO_Inclusion"] if trow["DO_Inclusion"] else ""

                match_name = difflib.SequenceMatcher(None, sname, tname).ratio()
                match_Aliases = difflib.SequenceMatcher(None, sAliases, tAliases).ratio()
                match_dob = difflib.SequenceMatcher(None, sdob, tdob).ratio()
                match_title = difflib.SequenceMatcher(None, stitle, ttitle).ratio()
                match_remarks = difflib.SequenceMatcher(None, sremarks, tremarks).ratio()
                match_dateinc = difflib.SequenceMatcher(None, str(sdateinc), str(tdateinc)).ratio()

                ratios = [match_name, match_Aliases, match_dob, match_title, match_remarks, match_dateinc]
                matched_attributes = len([m for m in ratios if m >= self.THRESHOLD])
                product = match_name * match_dob * match_title * match_remarks * match_dateinc

                if matched_attributes >= 5 and match_name > 0.40:
                    changes[(sindex, tindex)] = product

                    if match_name < 1.00:
                        value_change[(sindex, tindex, "Name")] = match_name

                    if match_Aliases < 1.00:
                        value_change[(sindex, tindex, "Aliases")] = match_Aliases

                    if match_dob < 1.00:
                        value_change[(sindex, tindex, "DOB")] = match_dob

                    if match_title < 1.00:
                        value_change[(sindex, tindex, "Title")] = match_title

                    if match_remarks < 1.00:
                        value_change[(sindex, tindex, "Remarks")] = match_remarks

                    if match_dateinc < 1.00:
                        value_change[(sindex, tindex, "DO_Inclusion")] = match_dateinc

        logging.info("End Identifying the changes for {}".format(self.program_name))
        return changes, value_change

    @staticmethod
    def _clean_string(string, words_to_remove):
        char_list = ['[', ']', '{', '}', ':', ',', '"']
        try:
            new_string = string.translate({ord(x): '' for x in char_list})
            for word in words_to_remove:
                new_string = new_string.replace(word, '')
        except (AttributeError, TypeError):
            new_string = ""

        return new_string.strip()

    def _record_modifications(self, changes, value_changes):
        logging.info("Record Modification start for {}".format(self.program_name))

        changed_rows = list(changes.keys())
        value_changes_cols = list(value_changes.keys())

        source_change_rows = list(self.source_df.index)
        target_change_rows = list(self.target_df.index)

        source_cdel = [r[0] for r in changed_rows]
        target_cadd = [r[1] for r in changed_rows]
        source_deletions = list(set(source_change_rows) - set(source_cdel))
        target_additions = list(set(target_change_rows) - set(target_cadd))

        if len(self.ScrapedTable):
            self.ScrapedTable = self.ScrapedTable.drop(self.ScrapedTable.index[source_deletions])
            try:
                self.ScrapedTable = self.ScrapedTable.append(self.ExistingTable.loc[target_additions])
            except KeyError:
                pass

        date = datetime.datetime.now()
        change_id = self._insert_changelog_record()

        for deletion in source_deletions:
            logging.debug("Deleting unwanted record for scrapper {}".format(self.program_name))
            entity_id = self._perform_eid_query(self.source_df.ix[deletion], self.old_sublist_id)
            self._execute_query("INSERT INTO tbl_changedetails VALUES(?,?,?,?,?,?,?,?)",
                                (change_id, None, None, date, None, "removal", self.new_sublist_id, entity_id))

        for addition in target_additions:
            logging.debug("Inserting new record for scrapper {}".format(self.program_name))
            entity_id = self._perform_eid_query(self.target_df.ix[addition], self.new_sublist_id)
            self._execute_query("INSERT INTO tbl_changedetails VALUES(?,?,?,?,?,?,?,?)",
                                (change_id, None, None, date, None, "addition", self.new_sublist_id, entity_id))

        for val in value_changes_cols:
            src = val[0]
            trg = val[1]
            col = val[2]

            entity_id = self._perform_eid_query(self.source_df.ix[src], self.old_sublist_id)

            self.ScrapedTable.at[src, col] = self.target_df.loc[trg, col]

            if col == 'DO_Inclusion':
                old_value = str(self.source_df.loc[src, col])
                new_value = str(self.target_df.loc[trg, col])
            else:
                old_value = json.dumps(self.source_df.loc[src, col])
                new_value = json.dumps(self.target_df.loc[trg, col])

            self._execute_query("INSERT INTO tbl_changedetails VALUES(?,?,?,?,?,?,?,?)",
                                (change_id, old_value, new_value, date, col, "modification", self.new_sublist_id,
                                 entity_id))
                                 
        logging.info("Record Modification end for {}".format(self.program_name))

    def _insert_changelog_record(self):
        INSERT_QUERY = "INSERT INTO tbl_listchangelog (ModifiedDate, SubListID) VALUES (?, ?);"
        SELECT_QUERY = "SELECT TOP 1 ChangeID FROM tbl_listchangelog ORDER BY ChangeID DESC;"

        date = datetime.datetime.now()
        self._execute_query(INSERT_QUERY, (date, self.new_sublist_id))
        insertetd_id = self._execute_query(SELECT_QUERY).fetchone()[0]
        return insertetd_id

    def _perform_eid_query(self, df_row, sublist_id):
        where_clause, values = self._create_where_clause(df_row, sublist_id)
        query = """SELECT EID from tbl_scrappedData WHERE {where};""".format(
            where=where_clause)
        try:
            result = self._execute_query(query, values).fetchone()[0]
            return result
        except TypeError:
            return None

    def _create_where_clause(self, df_row, sublist_id):
        cols = ['Name', 'Aliases', 'Title', 'DO_Inclusion']
        where_statements = []
        values = []
        for col in cols:
            statement = self._create_where_string(col, df_row[col])
            where_statements.append(statement)
            if df_row[col] is not None:
                values.append(df_row[col])

        remaining = ' and '.join(where_statements)
        where = "SubListID=? and {remainig_conditions}".format(remainig_conditions=remaining)
        values = [sublist_id] + values
        return where, values

    @staticmethod
    def _create_where_string(col_name, col_value):
        if col_value is not None:
            return "{name}=?".format(name=col_name)
        else:
            return "{name} is NULL".format(name=col_name)


def get_sublist_ids_of_changed_lists(list_ids):
    SUBWATCHLIST_QUERY = "SELECT TOP 2 tbl_subwatchlist.SubListID,  tbl_watchlist.IsStatic, tbl_subwatchlist.Program  FROM tbl_subwatchlist inner join tbl_watchlist On tbl_watchlist.ListID = tbl_subwatchlist.ListID WHERE tbl_subwatchlist.ListID = ?   ORDER BY SubListID DESC;"
    sublist_ids = []

    engine = sa.create_engine(CONNECTION_STRING)
    connection = engine.connect()

    for list_id in list_ids:
        sublists = connection.execute(SUBWATCHLIST_QUERY, (list_id,)).fetchall()
        try:
            if sublists[0][1] == 0:

                logging.info("Starting change detection for {}".format(sublists[0][2]))

                try:
                    changedet = ChangeDetection(connection, list_id, sublists[0][0], sublists[1][0], sublists[0][2])
                except IndexError:
                    changedet = ChangeDetection(connection, list_id, sublists[0][0], None, sublists[0][2])

                list_has_changes = changedet.detect()
                if list_has_changes:
                    sublist_ids.append(sublists[0][0])

                logging.info("Ending change detection for {}".format(sublists[0][2]))
        except Exception as e:
            logging.info("Error found on {} {}".format(list_id,e))
            send_error_email(list_id)

    connection.close()
    engine.dispose()
    return sublist_ids
