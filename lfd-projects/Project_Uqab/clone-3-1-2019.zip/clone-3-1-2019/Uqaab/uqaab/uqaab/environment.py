import os
from decouple import Config, RepositoryEnv

config = Config(RepositoryEnv('/home/amir/project/Uqaab/uqaab/.env'))