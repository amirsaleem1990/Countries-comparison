from datetime import datetime
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider

class un_consolidated(UqaabBaseSpider):
    name = "un_consolidated"

    start_urls = [
        '',
    ]

    def structure_valid(self, response):
        data_rows = response.css('table').css('tr').css('td')
        return len(data_rows) > 0

    def extact_data(self, response):
        data_rows = response.css('table').css('tr').css('td')
        for i in range(0, len(data_rows), 2):
            columns = data_rows[i].css('table').css('tr').css('td')

        yield Entity({
            'family-name': columns[0].css('::text').extract_first(),
            'given-name': columns[1].css('::text').extract_first(),
            'father-name': self.string_to_date(columns[2].css('::text').extract_first()),
            'date-of-birth': self.string_to_date(columns[3].css('::text').extract_first()),
            'place-of-birth': columns[0],
            'remarks': data_rows[i + 1].css('div.text::text').extract_first(),
            'source': response.url})

    @staticmethod
    def string_to_date(date_string):
        try:
            return datetime.strptime(date_string, '%d/%m/%Y')
        except TypeError:
            return None