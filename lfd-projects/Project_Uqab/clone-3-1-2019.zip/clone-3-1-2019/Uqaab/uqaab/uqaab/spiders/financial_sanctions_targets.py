import scrapy
import tabula
import io
import json
import re
import numpy as np
import pandas as pd
import datetime
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider
from uqaab.spiders.utils.base_customized_spiders import CATEGORY_OPTIONS

class financial_sanctions(UqaabBaseSpider):
    name = "financial_sanctions_scrapper"
    start_urls = ["http://hmt-sanctions.s3.amazonaws.com/sanctionsconlist.xls",]

    def structure_valid(self, response):
        return True

    def extact_data(self, response):
        with io.BytesIO(response.body) as resp_file:
            df = pd.io.excel.read_excel(resp_file, sheet_name='sanctionsconlist')

        add_col = [col for col in df if "Address 1" in col]

        for index, row in df.iterrows():
            name = self.extract_name(row["Name 1"])
            organization = self.extract_organization(row["Associated to"])

            addresses = self.extract_addresses(row[add_col])

            yield Entity({

                "name": name,
                "category": CATEGORY_OPTIONS[1],
                "address": addresses,
                "organization": organization,
                "type": "San"
            })

@staticmethod
def extract_name(data):
    return data


@staticmethod
def extract_addresses(row):
    n = list(row)
    addresses = []
    for add in n:
        add = str(add)
        if "nan" not in add:
            addresses.append(add)
    return addresses

@staticmethod
def extract_remarks(row):
    if row is np.nan:
        row = None
    return row

