from datetime import datetime
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider

class gb_targets(UqaabBaseSpider):
    name = "gb_targets"
    start_urls = ["https://www.insolvencydirect.bis.gov.uk/IESdatabase/viewdirectorsummary-new.asp"]

    # def structure_valid(self, response):

    def extract_data(self, response):
        data_rows = response.css('font')[0].css('face')[1:]
        for rows in data_rows:
            columns = rows.css('face')
            print(columns)
