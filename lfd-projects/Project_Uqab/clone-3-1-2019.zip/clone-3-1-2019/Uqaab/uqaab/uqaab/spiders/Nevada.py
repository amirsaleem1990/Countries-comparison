import scrapy
import traceback
import json
from scrapy.http import Request
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider
import dateparser

base_url = "http://gaming.nv.gov"

class NevadaSpider(UqaabBaseSpider):
    name = "nevada_gaming_control_board"
    allowed_domains = ["http://gaming.nv.gov"]

    start_urls = [
    'http://gaming.nv.gov/index.aspx?page=72',
    ]
    def structure_valid(self, response):
        return 100    

    def extact_data(self, response):

        print("                 *******Extracting GCB Excluded Person List*******")
        try:
            table = response.xpath("//*[@id='ctl00_content_Screen']")
            current_row = 1
            table_row_count = table.xpath('table/tbody/tr').extract()
            while current_row <= len(table_row_count):
                person_urls = table.xpath('table/tbody/tr[' + str(current_row) + ']/td/a/@href').extract()
                for person_url in person_urls:
                    if 'http://' not in person_url:
                        person_url = base_url + '/' + person_url
                    yield Request(person_url, callback=self.parse_person, dont_filter=True)
                current_row += 2
        except Exception as e:
            traceback.print_exc()
        print("                 *******Finished Extracting GCB Excluded Person List*******")


    def format_string_from_array(self, str_list, str_replace):
            return ' '.join([item.strip() for item in str_list]).replace(str_replace, '').strip()

    def parse_person(self, response):
        try:
            name = aka = gender = date_of_birth = place_of_birth = address = remarks = inclusion_date = ''
            temp = ''

            '''Get Remarks'''
            print('Fetching Record for GCB Excluded Person............................')
            print('========== URL: ' + response.url)
            temp = response.xpath('//*[@id="ctl00_content_Screen"]').css('p::text').extract()
            if len(temp) > 0:
                remarks = ' '.join([item.strip() for item in temp]).strip()
            
            print(remarks)

            table = response.xpath('//*[@id="ctl00_content_Screen"]').css('table')[0]

            '''Get Name'''
            temp = table.xpath('tbody/tr[1]/td[1]').css('::text').extract()
            if len(temp) > 0:
                name = ' '.join([item.strip() for item in temp]).replace('Name / Aliases', '').replace('Name', '').strip()
            print(name)


            temp = table.xpath('tbody/tr[1]/td[2]').css('::text').extract()
            if len(temp) > 0:
                aka = ' '.join([item.strip() for item in temp]).replace('Aliases', '').replace('AKA:', '').strip()
            print(aka)

            temp = table.xpath('tbody/tr[2]/td[1]/text()').extract()
            if len(temp) > 0:
                gender = temp[0].strip()
            print(gender)

            temp = table.xpath('tbody/tr[3]/td[1]/text()').extract()
            if len(temp) > 0:
                date_of_birth = ' '.join([item.strip() for item in temp]).strip()

            print(date_of_birth)

            temp = table.xpath('tbody/tr[3]/td[2]').css('::text').extract()
            if len(temp) > 0:
                place_of_birth = ' '.join([item.strip() for item in temp]).replace('Place of Birth', '').strip()
                dob = []
                dob.append({
                        'DOB': date_of_birth,
                        'POB': place_of_birth,
                        })
                
            print(dob)

            temp = table.xpath('tbody/tr[4]/td').css('::text').extract()
            if len(temp) > 0:
                address = ' '.join([item.strip() for item in temp]).replace('Last Known Address', '').strip()
            print(address)

            temp = table.xpath('tbody/tr[6]/td[1]').css('::text').extract()
            if len(temp) > 0:
                inclusion_date = self.format_string_from_array(temp, 'Placed on List')
                inclusion_date = dateparser.parse(inclusion_date)
            print(inclusion_date)

            yield Entity({
                'name': name,
                'aka': [aka],
                'gender': gender,
                'date_of_birth': json.dumps({'info': dob}),
                'address': [address], 
                'remarks': remarks,
                'inclusion_date': inclusion_date,
                'category': 'Individual'
            })
            print('Fetched and Stored Record for ' + str(name) + ' Wanted Fugitives')
        except Exception as e:
            traceback.print_exc()