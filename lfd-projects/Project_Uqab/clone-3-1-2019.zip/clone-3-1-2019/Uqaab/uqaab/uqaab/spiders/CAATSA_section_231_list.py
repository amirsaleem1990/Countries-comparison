import scrapy
import traceback
from scrapy.http import Request
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider

class CaatsaSectionListSpider(UqaabBaseSpider):
    name = "caatsa_section_231_list"
    allowed_domains = ["https://www.state.gov"]

    start_urls = [
    'https://www.state.gov/t/isn/caatsa/275116.htm',
    ]

    p2_path = "//*[@id='centerblock']/p[2]/text()"
    p4_path = "//*[@id='centerblock']/p[4]/text()"

    def structure_valid(self, response):
        return (len(response.xpath(self.p2_path)) or len(response.xpath(self.p4_path))) > 0

    def extact_data(self, response):
        print("                 *******Extracting CAATSA Section 231(d) List*******")

        try:
            name = ''
            p2_list = response.xpath(self.p2_path).extract()
            if self.structure_valid:
                for p2 in p2_list:
                    name = p2.strip()
                    print(name)
                    yield Entity({
                        'name': name
                    })
            else:
                print('Structure of ' + str(response.url) + ' has been changed. Unable to fetch List Regarding the Defense Sector.')


            p4_list = response.xpath(self.p4_path).extract()
            if self.structure_valid:
                for p4 in p4_list:
                    name = p4.strip()
                    print(name)
                    yield Entity({
                        'name': name
                    })
            else:
                print('Structure of ' + str(response.url) + ' has been changed. Unable to fetch List Regarding the Intelligence Sector.')

        except Exception as e:
            traceback.print_exc()

        print("                 *******Finished Extracting CAATSA Section 231(d) List*******")