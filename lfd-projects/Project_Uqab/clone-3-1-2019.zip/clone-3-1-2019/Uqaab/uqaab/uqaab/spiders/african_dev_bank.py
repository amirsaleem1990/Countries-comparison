from datetime import datetime
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider


class AfricanDevBankSpider(UqaabBaseSpider):
    name = "african_dev_bank"
    
    start_urls = [
        'http://www.afdb.org/en/projects-and-operations/procurement/debarment-and-sanctions-procedures/',
        ]

    def structure_valid(self, response):
        data_rows = response.css('tbody')[0].css('tr')
        return len(data_rows) > 0

    def extact_data(self, response):
        data_rows = response.css('tbody')[0].css('tr')
        for i in range(0, len(data_rows), 2):
            columns = data_rows[i].css('td')
            category = 'Individual' if columns[1].css('::text').extract_first() == 'Individual' else 'Group'
            yield Entity({
                'category': columns[0].css('::text').extract_first(),
                'name': columns[1].css('::text').extract_first(),
                'nationality': columns[2].css('::text').extract_first(),
                'inclusion_date': self.string_to_date(columns[3].css('::text').extract_first()),
                'exclusion_date': self.string_to_date(columns[4].css('::text').extract_first()),
                'remarks': data_rows[i+1].css('div.text::text').extract_first()
            })

    @staticmethod
    def string_to_date(date_string):
        try:
            return datetime.strptime(date_string, '%d/%m/%Y')
        except TypeError:
            return None