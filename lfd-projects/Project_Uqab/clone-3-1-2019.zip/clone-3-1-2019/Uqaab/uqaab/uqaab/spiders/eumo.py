import scrapy
import traceback
from scrapy.http import Request
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider
import dateparser

class ThirdcodeSpider(UqaabBaseSpider):
    name = 'eumo_scrapper'
    allowed_domains = ['eumostwanted.eu']
    start_urls = ['https://eumostwanted.eu/']

    def structure_valid(self, response):
        return 100

    def extact_data(self, response):
        mainList = response.css(".views-row")
        links = []
        for indiv in mainList:
            x = indiv.xpath('.//a/@href').extract()[0]
            links.append(x)
        for url in links:
            yield scrapy.Request(url, callback=self.parse_attr, errback=self.error_handler)
    
    def parse_attr(self, response):
        Name =  response.css(".field-name-title-field").xpath(".//h2/text()").extract()[0]
        DOB = response.css(".field-name-field-date-of-birth").xpath(".//span/text()").extract()[0]
        Nationality =  response.css(".field-name-field-nationality").xpath(".//li/text()").extract()[0] 
        
        yield {
            'name': Name,
            'date_of_birth': DOB,
            'nationality': Nationality
            }