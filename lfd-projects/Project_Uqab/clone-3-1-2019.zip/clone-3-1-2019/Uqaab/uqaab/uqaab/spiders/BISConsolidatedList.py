import scrapy
import io
import datetime
import re
import string
import requests
import pandas as pd
import numpy as np
import json
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider
from uqaab.spiders.utils.base_customized_spiders import CATEGORY_OPTIONS


class BISConsolidatedList(UqaabBaseSpider):

    name = "BISList_Spider"
    start_urls = ['https://api.trade.gov',]

    def structure_valid(self, response):
        return True

    def extact_data(self, response):

        url = "https://api.trade.gov/consolidated_screening_list/search.csv?api_key=OHZYuksFHSFao8jDXTkfiypO"
        r = requests.get(url)
        df = pd.read_csv(io.BytesIO(r.content))
        
        global DOB_info

        for index, row in df.iterrows():

        ####### extract entity info ###########

            name = self.extract_name(row["name"])
            title = self.extract_title(row["title"])
            address = self.extract_address(row["addresses"])
            inclusion_date = self.extract_record_date(row["start_date"])
            exclusion_date = self.extract_record_date(row["end_date"])
            nationality = self.extract_nationality(row["nationalities"])
            alias = self.extract_alias(row["alt_names"])
            remarks = self.extract_remarks(row["remarks"])
    
        ######### extract DOB POB info ###########

            DOB_info = []

            places = row["places_of_birth"]
            dates = row["dates_of_birth"]
            dates = str(dates)
            dates = dates.replace('to', '-')
            dates = dates.replace('.', '')
            dates = dates.replace('or', '|')
            dates = dates.replace(" ", '')
            dates = dates.strip()
            dates = dates.split(";")
            for date in dates:
                self.extract_dates(date, places)

            if len(DOB_info) > 0:
                DOB_complete = json.dumps({'info': DOB_info})
            else:
                DOB_complete = json.dumps({'info': None})
        
            yield Entity({
                "name" : name,
                "remarks": remarks,
                "date_of_birth" : DOB_complete,
                "inclusion_date" : inclusion_date,
                "exclusion_date" : exclusion_date,
                "aka" : alias,
                "category": CATEGORY_OPTIONS[0],
                "address" : address,
                "nationality":nationality,
                "title" : title
                })


    @staticmethod
    def extract_name(row):
        res = None
        if row is not np.nan:
            res = row
        return res

    @staticmethod
    def extract_title(row):
        res = []
        if row is not np.nan:
            res.append(row)
        return res
    
    @staticmethod
    def extract_remarks(row):
        res = None
        if row is not np.nan:
            res = row
        return res

    @staticmethod
    def extract_address(row):
        res = []
        if row is not np.nan:
            res.append(row)
        return res
    
    @staticmethod
    def extract_record_date(row):
        res = None
        if row is not np.nan:
            res = datetime.datetime.strptime(row, "%Y-%m-%d")
        return res

    @staticmethod
    def extract_source_url(row):
        res = None
        if row is not np.nan:
            res = row
        return res
    
    @staticmethod
    def extract_nationality(row):
        res = None
        if row is not np.nan:
            row = row.split(";")
            res = "|".join(row)
        return res
    
    @staticmethod
    def extract_alias(row):
        res = []
        if row is not np.nan:
            res = row.split(";")
        return res

    @staticmethod
    def extract_dates(date, places):
        DatesDict = {}
        year_pattern = re.compile(r"\d{4}")
        date_matched = re.findall(year_pattern, date)
        
        if len(date_matched) > 0:
            date = date_matched[0]

        if places is np.nan or places == "nan":
            places = None
        
        if date is np.nan or date == "nan":
            date = None 

        if date or places:
            DatesDict["DOB"] =  date
            DatesDict["POB"] = places
            DOB_info.append(DatesDict)