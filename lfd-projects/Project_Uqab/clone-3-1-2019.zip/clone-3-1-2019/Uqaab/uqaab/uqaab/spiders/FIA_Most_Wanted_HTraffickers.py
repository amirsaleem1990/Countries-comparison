import scrapy
import tabula
import io
import json
import re
import numpy as np
import pandas as pd
import datetime
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider
from uqaab.spiders.utils.base_customized_spiders import CATEGORY_OPTIONS

class FIA_HTraffickers(UqaabBaseSpider):
    name = 'fia_htraffickers_spider'
    start_urls = ["http://www.fia.gov.pk/en/redbooktriff.pdf",]

    def structure_valid(self, response):
        return True

    def extact_data(self, response):

        url = "http://www.fia.gov.pk/en/redbooktriff.pdf"
        hum = tabula.read_pdf(url, encoding="latin1", lattice=True, multiple_tables=True, pages="all")
        
        total_pages = len(hum)

        for page in range(24, total_pages):
            print("===============page===============")
            print(page)

            if page<116:

                case = hum[page]
                case = case.T
                case = case.dropna(axis=[0,1], how="all")
                cols = list(case.iloc[0])
                case.columns = cols
                case = case.iloc[1:]
                case = case.reset_index(drop=True)
                ## Name
                
                name = self.extract_name(case["NAME OF MWT:"][0]) + " S/0 " + str(case["PARENTAGE:"][0])
                ## Date of Birth
                dob_pob = {}
                if "DOB:" in case.columns:
                    dob = case["DOB:"][0]
                    try:
                        if len(dob) == 4:
                            dob =  dob + ' ' + '01' + ' ' + '01'
                            dob = str(datetime.datetime.strptime(dob, "%Y %m %d"))
                        elif "." in dob:
                            dob = str(datetime.datetime.strptime(dob, "%d.%m.%Y"))
                        elif dob.count("-")==2:
                            dob = str(datetime.datetime.strptime(dob, "%d-%m-%Y"))
                        else:
                            print("D O B ELSE")
                            dob = dob
                    except Exception:
                        print("D O B EXCEPTION")
                        dob = dob
                else:
                    dob = None
                if dob:
                    dob_pob["DOB"] = dob
                    dob_pob["POB"] = None

                
                if dob_pob:
                    DOB_complete = json.dumps({'info': [dob_pob]})
                else:
                    DOB_complete = json.dumps({'info': None})

                ## remarks
                r1 = case["TRAVEL HISTORY\rCOLLECTED:"][0]
                r2 = case["PASSPORT NUMBER:"][2]

                
                remarks = self.extract_remarks("Travel History: " + str(r1) + "|" + "Mobile Number: " +  str(r2))
                ## Address

                
                address = self.extract_address(str(case["ADDRESS:"][0].replace("\r","  ")).encode("utf-8"))

                ## Document 
                document = []
                doc = {}
                doc["type"] = "CNIC"
                if "DOB:" in case.columns:
                    doc["id"] = str(case["DOB:"][2])
                    document.append(doc)
                else:
                    doc["id"] = None
                
                doc = {}
                doc["type"] = "PASSPORT"
                doc["id"] = str(case["PASSPORT NUMBER:"][0])
                document.append(doc)
                document = json.dumps({'document_info': document})


                yield Entity({
                
                "name" : name,
                "remarks": remarks,
                "category": CATEGORY_OPTIONS[1],
                "date_of_birth": DOB_complete,
                "address": address,
                "country": "PK",
                "document" : document,
                "type" : "San",
            })

            else:
                d = pd.DataFrame()
                d = d.append([hum[pnum] for pnum in range(116,len(hum)-1)])
                d = d.reset_index(drop=True)
                cols = d.iloc[0]
                d.columns = cols
                d = d.iloc[1:]

                for index, row in d.iterrows():
                    p = re.compile(r"[a-zA-Z]+")
                    name = self.extract_name(row["NAME"])
                    document = []
                    doc = {}
                    value = row["CNIC"]
                    alp = p.findall(value)
                    if len(alp)>0:
                        value = None
                    doc["type"] = "CNIC"
                    doc["id"] = value
                    if value is not None:
                        document.append(doc)
                        document = json.dumps({'document_info': document})
                    else:
                        document = json.dumps({'document_info': None})
                    
                    address = self.extract_address(row["CIRCLE/AHTC"])
           
                    yield Entity({
                        "name" : name,
                        "category": CATEGORY_OPTIONS[0],
                        "address": address,
                        "country": "PK",
                        "document" : document,                 
                        "type" : "San",
                    })

    @staticmethod
    def extract_name(row):
        try:
            if row is np.nan:
                row = None
            return row

        except Exception:
            return None

            
    @staticmethod
    def extract_remarks(row):
        try:
            if row is np.nan:
                row = None
            return row

        except Exception:
            return None

    @staticmethod
    def extract_address(row):
        try:
            if row is np.nan:
                row = None
            return row

        except Exception:
            return None


        





