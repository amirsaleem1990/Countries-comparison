import scrapy
import tabula
import pandas as pd
import datetime
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider
from uqaab.spiders.utils.base_customized_spiders import CATEGORY_OPTIONS

class StageGovOrg(UqaabBaseSpider):
    name = 'state_gov_org_spider'
    start_urls = ["https://www.state.gov/documents/organization/284359.pdf",]

    def structure_valid(self, response):
        return True

    def extact_data(self, response):

        url = "https://www.state.gov/documents/organization/284359.pdf"

        data = tabula.read_pdf(url, encoding="latin1",multiple_tables=True, lattice=True, pages="all")
        
        total_pages = len(data)

        for page in range(0,total_pages):

            if page == 9:
                data_columns = ["SNO", "Name", "Country", "DO_Inclusion", "Status", "Notice", "Column7"]
            else:
                data_columns = ["SNO", "Name", "Country", "DO_Inclusion", "Status", "Notice"]
                
            page_data = data[page].iloc[1:]
            page_data.columns = data_columns

            for index,row in page_data.iterrows():

                name = row["Name"]
                
                country = row["Country"]
                
                inclusion_date = self.string_to_date(row["DO_Inclusion"])

                remarks = row["Notice"]
             
                status = row["Status"]

                yield Entity({

                    'category': "Group",
                    'name': name, 
                    "Status" : status, 
                    'inclusion_date': inclusion_date,
                    'remarks': remarks,
                    'type' : "San",
                    'country': self.get_country_code(country)
                    
            })

    @staticmethod
    def string_to_date(date_string):
        try:
            return datetime.datetime.strptime(date_string, '%m-%d-%Y')
        except (TypeError,ValueError):
            return None
