# -*- coding: utf-8 -*-
import scrapy
from datetime import datetime
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider
from uqaab.spiders.utils.base_customized_spiders import CATEGORY_OPTIONS
from scrapy import Request
from scrapy.http import HtmlResponse
import re
import json



class InterpolSpider(UqaabBaseSpider):

    name = 'interpol_wanted_spider'
    start_urls = ["https://www.interpol.int/notice/search/wanted"]

    def structure_valid(self, response):
        data_rows = response.xpath('//div[@class="bloc_bordure"]').extract()
        wanted_by_select = response.xpath('//select[@class="limited_select"]').extract()
        return len(data_rows) > 0 and len(wanted_by_select) > 0

    def extact_data(self, response):
        wanted_by_url = 'https://www.interpol.int/notice/search/wanted/(offset)/{offset}/(RequestingCountry)/{country}/(search)/1'
        wanted_by = response.xpath('//select[@class="limited_select"]/option').extract()
        wanted_by = wanted_by[1:]

        for country in wanted_by:
            value = self._remove_non_digits(country)
            url = wanted_by_url.format(offset=0, country=value)
            yield scrapy.Request(url=url, callback=self.extract_entity, errback=self.error_handler)
                   

    def extract_entity(self, response):
        try:
            next_page = "https://www.interpol.int" + response.xpath('//*[@id="content2"]/div[3]/div/div[2]/div/p/\
            span[@class="next"]/a/@href').extract_first()
        except Exception:
            next_page = None

        for entity in response.xpath('//div[@class="bloc_bordure"]/div'):

            E = Entity()

            E["name"] = self.extract_name(entity)
            E["category"] = "Individual"

            link = self.extract_link(entity)

            request =  Request(url=link, callback=self.extract_details)

            request.meta['E'] = E 
        
            yield request

        if next_page is not None:
            yield scrapy.Request(url=next_page, callback=self.extract_entity, errback=self.error_handler)

    def extract_details(self, response):

        E = response.meta['E']

        dob = response.xpath('//*[@id="result_details"]/div[1]/div[4]/table/tr[4]/td[2]/text()').\
                        extract_first().\
                        split()[0]

        place_of_birth = response.xpath('//*[@id="result_details"]/div[1]/div[4]/table/tr[5]/td[2]/text()').\
                        extract_first().\
                        replace('\n', '').replace('\t','')

        date = self.extract_date(dob)

        dob_pob = {}

        dob_pob["DOB"] = str(date)
        dob_pob["POB"] = place_of_birth

        country = response.xpath('//*[@id="result_details"]/div[1]/div[4]/table/tr[5]/td[2]/text()').\
                extract_first().\
                replace('\n', '').replace('\t','')


        remarks = response.xpath('//*[@id="result_details"]/div//p/text()').\
                    extract_first()\

        if dob_pob['DOB'] or dob_pob['POB']:
            DOB_info = json.dumps({'info': [dob_pob]})
        else:
            DOB_info = json.dumps({'info': None})

        E["date_of_birth"] = DOB_info
        E["country"] = self.get_country_code(country)
        E["remarks"] = remarks

        try:
            E["nationality"] = response.xpath('//*[@id="result_details"]/div[1]/div[4]/table/tr[7]/td[2]/text()').extract_first().strip()
        except AttributeError:
            pass

        try:
            E["gender"] = response.xpath('//*[@id="result_details"]/div[1]/div[4]/table/tr[3]/td[2]/text()').extract_first().strip()
        except AttributeError:
            pass

        return E


    @staticmethod
    def extract_name(entity):
        try:
            for text in entity.xpath('div[2]/span'):
                names = text.xpath('text()').extract()
                names = ('|').join(names)
            return names
        except Exception:
            return None

    @staticmethod
    def extract_date(dob):
        try:
            date = datetime.strptime(dob, "%d/%m/%Y")
            return date
        except ValueError:
            return None    

    @staticmethod
    def extract_link(entity):
        link = "https://www.interpol.int" + entity.xpath('div[3]/a/@href').extract_first()
        return link

    @staticmethod
    def _remove_non_digits(string):
        return re.sub(r'\D', "", string)
        