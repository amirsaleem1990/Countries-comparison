import scrapy
import traceback
from scrapy.http import Request
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider
import dateparser
import pandas as pd
import os


class FinCENSpider(UqaabBaseSpider):
    name = "financial_crimes_enforcement_network"
    allowed_domains = ["fincen.gov"]

    def structure_valid(self, response):
        return (response.body is not None) and (response.body is not '')

    def start_requests(self):
        payload = "site=AA"
        url = "https://www.fincen.gov/fcn/financial_institutions/msb/retrieve.msb.list.html"
        headers = {
            'content-type': "application/x-www-form-urlencoded"
        }

        yield Request(url, self.parse, method="POST", body=payload, headers=headers)

    def extact_data(self, response):
        print("                 *******Extracting MSB Registrant Search*******")
        try:
            print("Downloading Excel file..........")
            with open('2345145145.xls', 'wb') as f:
                f.write(response.body)

            print("Excel file downloaded.")

            df = pd.read_table(f.name)
            rows = df.itertuples(index=True)
            for row in rows:
                aliases = address = zip_code = city = country = remarks = inclusion_date = None

                name = row[1]


                if 'nan' not in str(row[2]):
                    aliases = row[2]

                if 'nan' not in str(row[3]):
                    address = row[3]

                if 'nan' not in str(row[6]):
                    zip_code = row[6]

                address = str(address) + str(zip_code)

                if 'nan' not in str(row[4]):
                    city = row[4]

                if 'nan' not in str(row[5]):
                    country = row[5]

                if 'nan' not in str(row[7]):
                    remarks = row[7]

                if 'nan' not in str(row[12]):
                    inclusion_date = row[12]
                    if inclusion_date is not '':
                        inclusion_date = dateparser.parse(inclusion_date)
                    else:
                        inclusion_date = None
                else:
                    inclusion_date = None

                #This condition is added because the starting from this is garbage for scrapping
                if "** ALL STATES & TERRITORIES FLAG" in str(name):
                    break

                if 'nan' not in str(name):
                    yield Entity({
                        'name': str(name),
                        'aka': [aliases],
                        'address': address,
                        'city': city,
                        'country': self.get_country_code(country),
                        'remarks': remarks,
                        'inclusion_date': inclusion_date,
                        'category': 'Group'
                    })
            os.remove(f.name)
        except Exception as e:
            traceback.print_exc()

        print(" *******Finished Extracting MSB Registrant Search*******")
