import subprocess
import pyodbc
from uqaab.environment import config
import sys
import json

CONNECTION_STRING = config('CONNECTION_STRING')


class ScrapperTest():

    def __init__(self, list_id, spider_name):
        self.connection = pyodbc.connect(CONNECTION_STRING)
        self.cursor = self.connection.cursor()
        self.list_id = list_id
        self.spider_name = spider_name

    def scrapper_tester(self):

        scrapy_command = 'scrapy crawl {spider_name} -a list_id={list_id}'.format(spider_name=self.spider_name,
                                                                                  list_id=self.list_id)
        p = subprocess.Popen(scrapy_command, shell=True, stdout=subprocess.PIPE)
        for line in p.stdout:
            print (line)
        p.wait()

        self.check_entities_validity()

    def check_entities_validity(self):
        entities = []
        rows = []
        SELECT_QUERY = 'SELECT top 1 * FROM dbo.tbl_subwatchlist WHERE ListID = {0} order by SubListID desc'.format(
            self.list_id)
        result = self.cursor.execute(SELECT_QUERY).fetchone()
        sublistid = result[0]

        self.cursor.execute("""select
                            [Name],
                            [ECategory] as 'Category',
                            [Title] ,
                            [Nationality],
                            [Gender],
                            concat('Organization : ',  Organization) as Organization,
                            concat('Designation :' , Designation) as Designation,
                            concat('DO_Inclusion : ',  DO_Inclusion) as DO_Inclusion,
                            concat('DO_Exclusion :' , DO_Exclusion) as DO_Exclusion,
                            concat('Last_Occupation : ',  Last_Occupation) as Last_Occupation,
                            [Aliases],
                            [DOB],
                            [Address]
                            from
                            tbl_entities
                    where SubListID = {sublistid}""".format(sublistid=sublistid))
        rows = self.cursor.fetchall()

        for row in rows:
            taliases = row[10]
            aka = None
            if taliases is not None and taliases != '':
                try:
                    aliases_dict = json.loads(taliases)
                    if aliases_dict['info'] is not None:
                        try:
                            aka = ' | '.join([alias['aka'] for alias in aliases_dict['info']])
                        except TypeError:
                            aka = ' | '.join([alias['aka']['aka'] for alias in aliases_dict['info']])
                        except KeyError:
                            aka = ' | '.join([alias['alias_name'] for alias in aliases_dict['info']])
                except JSONDecodeError:
                    aka = taliases

            tdob = row[11]
            dob = []
            pob = []
            if tdob is not None and tdob != '':
                try:
                    dob_list = json.loads(tdob)
                    if isinstance(dob_list, dict):
                        if dob_list["info"] is not None:
                            for item in dob_list["info"]:
                                try:
                                    tdob = item['DOB']
                                except KeyError:
                                    tdob = item['date_of_birth']['Date of Birth']
                                if tdob is not None and tdob.lower() != 'nan':
                                    dob.append(str(tdob))
                                try:
                                    tpob = item['POB']
                                except KeyError:
                                    tpob = item['date_of_birth']['Place of Birth']
                                if tpob is not None and tpob != math.isnan(float('NaN')):
                                    pob.append(str(tpob))
                    else:
                        for item in dob_list:
                            tdob = item['DOB']
                            if tdob is not None and tdob.lower() != 'nan':
                                dob.append(str(tdob))
                            tpob = item['POB']
                            if tpob is not None and tpob != math.isnan(float('NaN')) and str(tpob).lower() != 'nan':
                                pob.append(str(tpob))
                except JSONDecodeError:
                    dob.append(tdob)

            dob = ' | '.join(dob)
            pob = ' | '.join(pob)

            taddress = row[12]
            addressList = None
            addresses = []
            if taddress is not None and taddress != '':
                try:
                    address_dict = json.loads(taddress)
                    if address_dict["address info"] is not None:
                        for item in address_dict["address info"]:
                            address_list = []
                            if item['address'] is not None:
                                address_list.append(item['address'])
                            if item['city'] is not None:
                                address_list.append(item['city'])
                            if item['country'] is not None:
                                address_list.append(item['country'])
                            addresses.append(','.join(address_list))
                        addressList = ' | '.join(addresses)
                except JSONDecodeError:
                    addressList = taddress

            entities.append({
                'Name': row[0],
                'Category': row[1],
                'Title': row[2],
                'Nationality': row[3],
                'Gender': row[4],
                'Remarks': row[5] + ' , ' + row[6] + ' , ' + row[7] + ' , ' + row[8] + ' , ' + row[9],
                'Aliases': aka,
                'DOB': dob,
                'POB': pob,
                'Address': addressList

            })

        print("total rows from query", len(rows))
        print("total rows of entities", len(entities))

        if len(rows) < 0:
            print ("No entities fetched, scrapper not ran successfully")
        elif len(entities) < len(rows):
            print ("scrapper does not fetched proper data")
        else:
            print ("Scrapper ran successfully and  fetched proper records")


if __name__ == "__main__":
    try:
        scrapper_test = ScrapperTest(int(sys.argv[1]), sys.argv[2])
        scrapper_test.scrapper_tester()
    except IndexError:
        print ('Missing argument! Format of running this script is "python scrapper_test.py list_id spider_name"')
