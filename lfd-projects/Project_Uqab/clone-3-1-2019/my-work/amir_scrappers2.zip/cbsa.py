import requests
from bs4 import BeautifulSoup
import pandas as pd

def glob():
    url = "https://www.cbsa-asfc.gc.ca/do-rb/provinces/bc-eng.html"
    d = {'links' : [], 'tags' : []}
    r = requests.get(url)
    if r.status_code == 200:
        html = r.text
        soup = BeautifulSoup(html, 'lxml')
        a = soup.find("table", { "id" : "offices"}).findAll("tr")[1:]
        for i in a:
            d['tags'].append(i.get_text())
            d['links'].append("https://www.cbsa-asfc.gc.ca/do-rb/" + i.find('a')['href'][3:])
    return d

Name = []
Region = []
District = []
Contact = []


def to_csv():
    data = glob()
    df = pd.DataFrame()
    d = {'Name':[], 'Region':[], 'District':[], 'Contact Us':[]}

    for url, tag in zip(data['links'], data['tags']):
        r = requests.get(url)
        if r.status_code == 200:
            html = r.text
            soup = BeautifulSoup(html, 'lxml')
            a = soup.find("tbody")
            for key, value in zip(a.select("th"), a.select("td")):
                if key.get_text().strip() in d:
                    if key.get_text().strip() == 'Name':
                        Name.append(value.get_text().strip())
                    elif key.get_text().strip() == 'Region':
                        Region.append(value.get_text().strip())
                    elif key.get_text().strip() == 'District':
                        District.append(value.get_text().strip())
                    elif key.get_text().strip() == 'Contact Us':
                        Contact.append(value.get_text().strip())
    df['name'] = Name
    df['address'] = ["Region: " + Region[i] + ", District: " + District[i] for i in range(len(Region))]
    df['Contact'] = [i.replace("\r\n\t\t\t\t", " ") for i in Contact]
    df
    return df

data_frame = to_csv()
data_frame.to_csv('cbsa.csv', index=False)