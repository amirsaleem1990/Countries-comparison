from bs4 import BeautifulSoup
import pandas as pd
import requests

url = "https://tradecommissioner.gc.ca/italy-italie/visit-info-visiteur/6842.aspx?lang=eng#rome"
try:
    html = requests.get(url).text
    soup = BeautifulSoup(html, "lxml")
    link = []
    name = []
    tel = []
    fax = []
    email = []
    act = []
    c = 1
    a = soup.find("div", {"class" : "span-6"}).findAll("p")[2:]
    for i in a[:16]:
        aa = str(i).replace("<br/>", "\n").splitlines()#.splitlines()))
        if ' '.join(aa).split().count("Tel.:") > 1:
            aa = ' '.join(aa).replace("Tel", "", 1)
        for z in aa:        
            if not z.startswith("<p><a href"):
                pass
            else:
                name.append(z[z.index("<strong>")+8:].replace("</strong></a>", "").strip())
            if z.startswith("Tel"): tel.append(z)
            if z.startswith("Fax"): fax.append(z)
            if z.startswith("Email"): email.append(z.replace("<a href=", "").replace("</strong></a>", ""))
            if z.startswith("Activities"): act.append(z.replace("</p>", ""))
        if len(tel) != c:  tel.append(' ')
        if len(name) != c: name.append(' ')
        if len(fax) != c: fax.append(' ')
        if len(email) != c: email.append(' ')
        if len(act) != c: act.append(' ')
        c += 1
        
    email = [i[i.find(':')+3:i.rfind('"')] for i in email]
    df = pd.DataFrame()
    fax = [i[i.find("+"):].replace("</p>", "") for i in fax]
    tel = [i[i.find("+"):].replace("</p>", "") for i in tel]
    e = [i[i.find(':')+3:i.rfind('"')] for i in email]
    df['contact'] = ["Fax: {} ||Email: {} ||Tel: {}".format(fax[i], e[i], tel[i]) for i in range(len(fax))]
    df['name'] = name 
    df['remarks'] = act
    df.to_csv("tradecommissioner.csv", index=False)
        
        
except:
    pass