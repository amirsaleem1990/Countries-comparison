import requests
from bs4 import BeautifulSoup
import pandas as pd
url = "https://www.usmarshals.gov/history/directors.htm"
r = requests.get(url)
if r.ok:
    html = r.text
    soup = BeautifulSoup(html, "lxml")
    a = soup.find("div", {"id" : "content"}).findAll("tr")
    z = [i.strip() for i in a[0].get_text().replace("\n\t", '').replace("\t\t", "").replace("\xa0", "").replace("\t", "").splitlines() if i][4:-20]
    for i in range(z.count("")):
        z.remove("")
    df = pd.DataFrame()
    df['name'] = z[0::3]
    df['title'] = z[1::3]
    df['remarks'] = ["Appointed: " + i for i in z[2::3]]
    df.to_csv("usmarshals.csv", index=False)