import requests
from bs4 import BeautifulSoup
import pandas as pd

url = "https://www.international.gc.ca/world-monde/international_relations-relations_internationales/sanctions/consolidated-consolide.aspx?lang=eng"
r = requests.get(url)
if r.status_code == 200:
    html = r.text
    soup = BeautifulSoup(html, 'lxml')
    
a = soup.find("table", { "id" : "dataset-filter" }).findAll("tr")[1:]
lst = []
for i in a:
    lst.append(i.select("td"))
    
df = pd.DataFrame()

Country_Regulation = []
Entity = []
Title = []
Last_Name = []
Given_Names = []
Aliases = []
Date_of_Birth = []

for row in lst:
    c = 0
    for i in range(len(row)):
        if c == 0:
            if not row[i].get_text().isprintable():
                Country_Regulation.append(' ')
            else:
                Country_Regulation.append(row[i].get_text())

        if c == 1:
            if not row[i].get_text().isprintable():
                Entity.append(' ')
            else:
                Entity.append(row[i].get_text())

        if c == 2:
            if not row[i].get_text().isprintable():
                Title.append(' ')
            else:
                Title.append(row[i].get_text())

        if c == 3:
            if not row[i].get_text().isprintable():
                Last_Name.append(' ')
            else:
                Last_Name.append(row[i].get_text())

        if c == 4:
            if not row[i].get_text().isprintable():
                Given_Names.append(' ')
            else:
                Given_Names.append(row[i].get_text())

        if c == 5:
            if not row[i].get_text().isprintable():
                Aliases.append(' ')
            else:
                Aliases.append(row[i].get_text())
        if c == 6:
            if not row[i].get_text().isprintable():
                Date_of_Birth.append(' ')
            else:
                Date_of_Birth.append(row[i].get_text())
        c += 1

df['country'] = Country_Regulation
df['name'] = [Entity[i] + ' ' + Last_Name[i] for i in range(len(Entity))]
df['title'] = Title
df['aka'] = [Aliases[i] + ' ' + Given_Names[i] for i in range(len(Given_Names))]
df['date_of_birth'] = Date_of_Birth
df.to_csv("international_gc.csv", index = False)