import requests
from bs4 import BeautifulSoup
import pandas as pd
import os
url = "https://www.securities-administrators.ca/cease_trade.aspx?id=171"
r = requests.get(url)
if r.status_code == 200:
    html = r.text
    soup = BeautifulSoup(html, 'lxml')
    
a = soup.find("div", { "id" : "ctl00_bodyContent_cb_qlink" })
second_url = a.find('a')['href']
r = requests.get(second_url)
if r.status_code == 200:
    html = r.text
    soup = BeautifulSoup(html, 'lxml')
    a = soup.find("div", { "id" : "ctl00_bodyContent_pnl_banner" }) 
    download_link = "https://cto-iov.csa-acvm.ca/" + soup.select(".link")[-1]['href']
    import os
    os.system("curl {} > cto_iov_csa_acvm.xls".format(download_link))