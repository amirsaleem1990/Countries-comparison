import requests
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
import os

url = "http://www.osfi-bsif.gc.ca/Eng/fi-if/amlc-clrpc/atf-fat/Pages/default.aspx"
try:
    html = requests.get(url).text
    soup = BeautifulSoup(html, "lxml")
    a = soup.find("div", {"id" : "cont"}).findAll("div")[3:5]
    links = ["www.osfi-bsif.gc.ca/" + i.find("td").find("a")['href'] for i in a]
except:
    pass

file_names = []
for i in links:
    name = i[i.rfind("/")+1:]
    os.system("curl {} > {}".format(i, name))
    file_names.append(name)

ind = pd.read_excel(file_names[0])
new_header = ind.iloc[4]
ind = ind[5:]
ind.columns = new_header
ind = ind[ind.index.notnull()]
ind = ind.replace(np.nan, '', regex=True)

names = ind[['Second Name2', 'Third Name2', 'Fourth Name2', 'Last Name 2']]
names["a"] = names["Second Name2"] + ", " +  names["Third Name2"] + ", " + names["Fourth Name2"] + ", " + names["Last Name 2"] 
names['a'] = [i.replace(", ,", "").strip(" ,") for i in names['a']]
ind = ind.drop(['Last Name 2', 'Second Name2', 'Third Name2', 'Fourth Name2'],axis=1)
ind['Aliases'] = names['a']
ind.to_excel("ok_" + file_names[0], index=False)


ent = pd.read_excel(file_names[1])
new_header = ent.iloc[3]
ent = ent[4:]
ent.columns = new_header
ent = ent[ent.Entity.notnull()]
ent= ent.replace(np.nan, '', regex=True)
ent.to_excel("ok_" + file_names[1], index=False)
for i in file_names:
    os.remove(i)
