import requests
from bs4 import BeautifulSoup
import pandas as pd

url = "https://en.wikipedia.org/wiki/Category:Non-profit_organisations_based_in_Brazil"
r = requests.get(url)
if r.ok:
    html = r.text
    soup = BeautifulSoup(html, "lxml")
    lst = []
    alphabets = soup.find("div", {"class" : "mw-category"}).findAll("div")
    links = []
    names = []
    for i in alphabets:
        for z in i.findAll("li"):
            links.append("https://en.wikipedia.org/" + z.find("a")['href'])
            names.append(z.get_text())
    df = pd.DataFrame()
    df['names'] = names
    df['links'] = links
    df.to_csv("non_profit_brazil.csv")
