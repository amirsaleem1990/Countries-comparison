import requests
import pandas as pd
from bs4 import BeautifulSoup
url = "https://travel.gc.ca/travelling/advisories"
r = requests.get(url)
if r.ok:
    html = r.text
    soup = BeautifulSoup(html, "lxml")
    Destination = []
    Advisory = []
    updated = []
    a = soup.find("table", {"id" : "reportlist"}).findAll("tr")
    for z in range(len(a)):
        aa = [i for i in a[z].get_text().splitlines() if i][1:]
        Destination.append(aa[0])
        Advisory.append(aa[1])
        updated.append(aa[2])
    df = pd.DataFrame()
    df['Destination'] = Destination
    df['Advisory'] = Advisory
    df['updated'] = updated
    df = df.iloc[1:]
    df.to_csv("travel.csv", index=False)
    print("File downloaded with name travel.csv")
