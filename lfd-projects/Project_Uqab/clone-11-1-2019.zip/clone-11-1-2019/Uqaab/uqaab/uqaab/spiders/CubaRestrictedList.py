import scrapy
import traceback
from scrapy.http import Request
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider

class CubaRestrictedListSpider(UqaabBaseSpider):
    name = "cuba_restricted_list"
    allowed_domains = ["https://www.state.gov"]

    start_urls = [
    'https://www.state.gov/e/eb/tfs/spi/cuba/cubarestrictedlist/275331.htm',
    ]

    content_path = "//*[@id='centerblock']/div/*"

    def structure_valid(self, response):
        return len(response.xpath(self.content_path)) > 0    

    def extact_data(self, response):
        print("                 *******Extracting List of Restricted Entities and Subentities Associated With Cuba as of November 9, 2017*******")

        content = response.xpath(self.content_path)
        content = content[2:]

        if self.structure_valid:
            address = name = ''

            for tag in content:
                if(len(tag.css('h1::text').extract())) > 0:
                    address = tag.css('h1::text').extract()[0].strip()
                elif(len(tag.css('p::text').extract())) > 0:
                    name = tag.css('p::text').extract()[0].strip()

                    yield Entity({
                        'address': [address],
                        'name': name
                    })
        else:
            print('Structure of ' + str(response.url) + ' has been changed. Unable to find required list.')

        print("                 *******Finished Extracting List of Restricted Entities and Subentities Associated With Cuba as of November 9, 2017*******")