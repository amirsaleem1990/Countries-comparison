from datetime import datetime
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider


class SGPMASSpider(UqaabBaseSpider):
    name = "sgp_mas"
    
    start_urls = [
        'http://www.mas.gov.sg/IAL.aspx?sc_p=all',
        ]

    def structure_valid(self, response):
        entries = response.css('li.vcard')
        return len(entries) > 0

    def extact_data(self, response):
        entries = response.css('li.vcard')
        for entry in entries:
            yield Entity({
                'name': entry.css('h2::text').extract_first(),
                'address': self.extract_addresses(entry.css('div.adr p')),
                'inclusion_date': self.extract_inclusion_date(entry.css('div.adr p em::text').extract_first()),
                'category': 'Group'
            })

    def extract_addresses(self, paragraphs):
        addresses = []
        for p in paragraphs:
            address_parts = p.css('::text').extract()
            address = self.clean_address(address_parts)
            if address:
                addresses.append(address)

        return addresses

    def clean_address(self, address_parts):
        address_string = ' '.join([item.replace('\n', '').replace('\r', '') for item in address_parts])
        address_string = self.remove_unwanted_strings(address_string)
        return address_string.strip()

    def remove_unwanted_strings(self, address):
        address = self.remove_string_from(address, 'Tel:')
        address = self.remove_string_from(address, 'Telephone:')
        address = self.remove_string_from(address, 'Website:')
        address = self.remove_string_from(address, 'Websites:')
        address = self.remove_string_from(address, 'Email:')
        address = self.remove_string_from(address, 'Emails:')
        address = self.remove_string_from(address, '[Listed')
        return address

    @staticmethod
    def remove_string_from(address, to_remove):
        try:
            _index = address.index(to_remove)
            return address[0 : _index]
        except ValueError:
            return address

    def extract_inclusion_date(self, listed_on):
        try:
            date_string = listed_on.replace('[Listed on', '').replace(']', '')
            if '\xa0' in date_string:
                date_string = date_string.replace('\xa0', ' ')
            return self.string_to_date(date_string.strip())
        except AttributeError:
            return None

    @staticmethod
    def string_to_date(date_string):
        try:
            return datetime.strptime(date_string, '%d %B %Y')
        except ValueError:
            return None