# Author: Huzaifa Qamer

from datetime import datetime
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider


class CsaSpider(UqaabBaseSpider):
    name = 'canadian_securities_administrators'
    start_urls = ['https://cto-iov.csa-acvm.ca/SearchArticles.asp?Instance=101&Form=1&Attr7=1&Attr3=1&am']

    def structure_valid(self, response):
        data_rows = response.css('table')[9].css('tr')
        return len(data_rows) > 0

    def extact_data(self, response):
        data_rows = response.css('table')[9].css('tr')

        for row_idx in range(1, len(data_rows), 2):
            try:
                row = data_rows[row_idx]
                name = row.css('td')[2].css('::text').extract_first()
                inclusion_date = row.css('td')[0].css('::text').extract_first()
                exclusion_date = row.css('td')[8].css('::text').extract_first()

                yield Entity({
                    'category': 'Group',
                    'name': name,
                    'inclusion_date': self.string_to_date(inclusion_date),
                    'exclusion_date': self.string_to_date(exclusion_date),
                    'type': 'SAN'
                })
            except IndexError:
                pass
        
        next_title = response.css('table')[10].css('tr img::attr(title)').extract()[-1]
        if next_title == 'Next Results >>':
            next_link = response.css('table')[10].css('tr a::attr(href)').extract()[-1]
            yield response.follow(next_link, callback=self.extact_data)

    @staticmethod
    def string_to_date(date_string):
        try:
            return datetime.strptime(date_string, '%Y/%m/%d')
        except ValueError:
            return None
