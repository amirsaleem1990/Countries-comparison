import scrapy
import traceback
from scrapy.http import Request
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider

base_url = "https://www.dea.gov"

class DrugEnforcementAgencySpider(UqaabBaseSpider):
    name = "drug_enforcement_agency_list"
    allowed_domains = ["https://www.dea.gov"]

    start_urls = [
    'https://www.dea.gov/fugitives.shtml',
    ]
    def structure_valid(self, response):
        divs = response.xpath("//*[@id='PLFugitive-LeftColumnMostWanted']")
        return len(divs) > 0  

    def extact_data(self, response):
        divs = response.xpath("//*[@id='PLFugitive-LeftColumnMostWanted']")
        
        top_wanted = divs[0]
        wanted = divs[1]

        print("                 *******Extracting DEA Wanted Fugitives*******")
        try:
            current_row = 1
            top_wanted_table_row_count = wanted.xpath('ul/table[' + str(current_row) + ']/tr').extract()
            while current_row <= len(top_wanted_table_row_count):
                top_wanted_urls = top_wanted.xpath('ul/table/tr[' + str(current_row) + ']/td/a/@href').extract()
                for individual_url in top_wanted_urls:
                    individual_url = base_url + '/' + individual_url
                    yield Request(individual_url, callback=self.parse_wanted_fugitive, dont_filter=True)

                current_row += 2
        except Exception as e:
            traceback.print_exc()

        try:
            current_row = 2
            wanted_table_row_count = wanted.xpath('ul/table[' + str(current_row) + ']/tr').extract()
            while current_row <= len(wanted_table_row_count):
                wanted_urls = wanted.xpath('ul/table[2]/tr[' + str(current_row) + ']/td/a/@href').extract()
                for individual_url in wanted_urls:
                    individual_url = base_url + '/' + individual_url
                    yield Request(individual_url, callback=self.parse_wanted_fugitive, dont_filter=True)

                current_row += 5
        except Exception as e:
            traceback.print_exc()
        print("                 *******Finished Extracting DEA Wanted Fugitives*******")


    def parse_wanted_fugitive(self, response):
        try:
            name = aka = gender = date_of_birth = nationality = address = remarks = ''
            temp = ''

            temp = response.css('#fugitivePhotoName::text').extract()
            if len(temp) > 0 :
                name = temp[0].strip()
            print(name)

            print('Fetching Record for ' + str(name) + ' Wanted Fugitives.......')
            
            info_html_table = response.xpath('//*[@id="fugitiveProfile"]')
            
            temp = info_html_table.xpath('tr[4]/td[2]/text()').extract()
            if len(temp) > 0 :
                aka = temp[0].strip()
            print(aka)

            temp = info_html_table.xpath('tr[6]/td[2]/text()').extract()
            if len(temp) > 0 :
                gender = temp[0].strip()
            print(gender)

            temp = info_html_table.xpath('tr[11]/td[2]/text()').extract()
            if len(temp) > 0:
                date_of_birth = temp[0].strip()
            print(date_of_birth)

            temp = info_html_table.xpath('tr[12]/td[2]/text()').extract()
            if (len(temp)) > 0:
                nationality = temp[0].strip()
            print(nationality)

            temp = info_html_table.xpath('tr[13]/td[2]/text()').extract()
            if (len(temp)) > 0:
                address = temp[0].strip()
            print(address)

            temp = info_html_table.xpath('tr[14]/td[2]/text()').extract()
            if len(temp) > 0:
                remarks = temp[0].strip()
            print(remarks)

            yield Entity({
                'category': 'Individual',
                'name': name,
                'nationality': nationality, 
                'remarks': remarks,
                'aka': [aka],
                'date_of_birth': date_of_birth,
                'gender': gender,
                'address': [address],
            })
            print('Fetched and Stored Record for ' + str(name) + ' Wanted Fugitives')
        except Exception as e:
            traceback.print_exc()