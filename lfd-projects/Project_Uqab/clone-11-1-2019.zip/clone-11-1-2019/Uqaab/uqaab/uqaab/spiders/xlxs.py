from datetime import datetime
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider
from scrapy.http import Request
import pandas as pd

class gb_targets(UqaabBaseSpider):
    name = "belgium_xls"
    start_urls = ["https://finance.belgium.be/en/about_fps/structure_and_services/general_administrations/"
                  "treasury/financial-sanctions/national"]

    path = "./"
    def structure_valid(self, response):
        return 100

    def extact_data(self, response):
        df = pd.read_excel("belgium_xls.xls")
        for href in response.css('p').css('span').css('a').extract():
            yield Request(
                url=response.urljoin(href),
                callback=self.parse_article)

            for i in range(0, len(href)):

                yield Entity({
                    'name': df[0],
                    'address': df[1],
                    'zip_code': df[2],
                    'city': df[3],
                    'country': df[4],
                    'date_of_birth': df[5],
                    'List_Name': df[6],
                    'national_id': df[7],
                    'title': df[8],
                    'listed_on': df[9],
                    'designation': df[10],
                    'remarks': df[11],
                    'do_inclusion': df[12],
                    'organization': df[13],
                    'category': df[14],
                    'exclusion_date': df[15],
                    'sanction_type': 'san'
                })

    def parse_xls(self, response):
        for href in response.css('p').css('span').css('a').extract():
            yield Request(
                url=response.urljoin(href),
                callback=self.save_xls
            )

    def save_xls(self, response):
        path = response.url.split('/')[-1]
        self.logger.info('Saving XLS %s', path)
        with open(path, 'wb') as f:
            f.write(response.body)



