from datetime import datetime
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider


class ErdbEntitiesSpider(UqaabBaseSpider):
    name = 'ERDB-Entities'
    # allowed_domains = ['www.ebrd.com/ineligible-entities-list.html']
    start_urls = ['https://www.ebrd.com/ineligible-entities-list.html']

    def structure_valid(self, response):
        data_rows = response.css('tbody')[0].css('tr')
        return len(data_rows) > 0

    def extact_data(self, response):
        data_rows = response.css('table')[0].css('tr')[1:]
        for row in data_rows:
            columns = row.css('td')

            yield Entity({
                'name': columns[0].css('::text')[0].extract(),
                # 'address': columns[1].css('p::text')[0].extract().strip()+ ' ' +columns[1].css('p::text')[1].extract().strip() + ' '+ columns[1].css('p::text')[2].extract().strip(),
                # + ' '  +columns[1].css('p::text')[3].extract().strip()
                'nationality': columns[2].css('::text')[0].extract().strip(),
                'country': [self.get_country_code(columns[2].css('::text')[0].extract().strip())],
                'inclusion_date': self.string_to_date(columns[3].css('dt::text')[0].extract().strip()),
                'exclusion_date': self.string_to_date(columns[4].css('dt::text')[0].extract().strip()),
                'remarks': columns[7].extract().replace('\r','').replace('\t','').replace('\n','') + ', Originating Institution :' + columns[6].extract().replace('<td>','').replace('</td>',''),
                'category': 'Group'
            })

    @staticmethod
    def string_to_date(date_string):
        try:
            return datetime.strptime(date_string, '%d %b %Y')
        except ValueError:
            return None