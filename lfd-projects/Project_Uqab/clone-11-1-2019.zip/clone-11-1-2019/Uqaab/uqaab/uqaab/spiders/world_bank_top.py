from datetime import datetime
import string
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider


class WorldBankTopSpider(UqaabBaseSpider):
    name = "world_bank_top"
    
    start_urls = [
        'http://web.worldbank.org/external/default/main?theSitePK=84266&contentMDK=64069844&menuPK=116730&pagePK=64148989&piPK=64148984',
        ]

    def structure_valid(self, response):
        data_rows = response.css('table.tableBorderGrey tr')[4 : ]
        return len(data_rows) > 0

    def extact_data(self, response):
        data_rows = response.css('table.tableBorderGrey tr')[4 : ]
        for row in data_rows:
            columns = row.css('td')

            yield Entity({
                'name': columns[0].css('font::text').extract_first().rsplit('*', 1)[0].strip(),
                'address': self.extract_address(columns[1]),
                'country': self.get_country_code(columns[2].css('font::text').extract_first().strip()),
                'inclusion_date': self.string_to_date(columns[3].css('font::text').extract_first().strip()),
                'exclusion_date': self.string_to_date(columns[4].css('font::text').extract_first().strip()),
                'remarks': columns[5].css('font::text').extract_first().strip()
            })

    def extract_address(self, column):
        return ' '.join([item.strip(string.punctuation).strip() for item in column.css('font::text').extract()])

    @staticmethod
    def string_to_date(date_string):
        try:
            return datetime.strptime(date_string, '%d-%b-%Y')
        except ValueError:
            return None