import re
from datetime import datetime
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider
import scrapy
import requests
import json


class Nacta(UqaabBaseSpider):
    name = "nacta"

    start_urls = [
        'https://www.proxynova.com/proxy-server-list/country-pk/',
    ]
    proxy_ip = None
    proxy_port = None
    form_url = 'http://103.226.217.232:8070/'

    def structure_valid(self, response):
        return True

    def extact_data(self, response):
        selector = scrapy.Selector(response=response)
        ip_address_table = selector.xpath('//*[@id="tbl_proxy_list"]//tr')

        for row in ip_address_table[2:-1]:
            try:
                self.proxy_port = row.xpath('td[2]//a/text()').extract_first()
                self.proxy_ip = row.css("td abbr").xpath('@title').extract_first()
                # To check this proxy will run the required site
                proxies = {
                    "http": "http://{}:{}".format(self.proxy_ip, self.proxy_port)
                }
                response = requests.get(self.form_url, proxies=proxies)
                break
            except:
                continue

        callback = lambda response: self.extract_form_data(response)
        yield scrapy.Request(url=self.form_url, callback=callback,
                             meta={'proxy': self.proxy_url(self.proxy_ip, self.proxy_port)})

    def extract_form_data(self, response, page=None, last_page=None):
        for entity in self.extract_items(response, page, last_page):
            yield entity

    def extract_items(self, response, page=None, last_page=None):
        selector = scrapy.Selector(response=response)
        view_state = selector.xpath('//*[@id="__VIEWSTATE"]/@value').extract_first()
        event_validation = selector.xpath('//*[@id="__EVENTVALIDATION"]/@value').extract_first()
        total_records = selector.xpath('//*[@id="MainContent_lblCount"]/text()').extract_first()
        rows = selector.xpath('//*[@id="MainContent_gvCustomers"]//tr')

        try:
            page = page + 1
        except TypeError:
            page = 2
            last_page = round(int(total_records) / 100)

        for row in rows[1:-2]:
            name = row.xpath('td[2]//text()').extract_first()
            orig_name = self.extract_name(name)
            aka = self.extract_aka(name)
            father_name = row.xpath('td[3]//text()').extract_first()
            remarks = "Father Name: " + father_name
            city = row.xpath('td[5]//text()').extract_first()
            address = city + ' ' + row.xpath('td[4]//text()').extract_first()


            name = orig_name + ' ' + father_name.replace('-','')

            yield Entity({
                'name': name.strip(),
                'city': city,
                'address':address,
                'country': "Pakistan",
                'remarks': remarks,
                'category': 'Individual',
                "type": "SIP",
                "aka":aka
            })

        if page <= last_page:
            formdata = {
                # change pages here
                "__EVENTTARGET": "ctl00$MainContent$gvCustomers",
                "__EVENTARGUMENT": "Page${}".format(page),
                "__VIEWSTATE": view_state,
                "__EVENTVALIDATION": event_validation,
            }

            callback = lambda response: self.extract_form_data(response, page, last_page)
            yield scrapy.FormRequest(url=self.form_url, formdata=formdata, callback=callback,
                                     meta={'proxy': self.proxy_url(self.proxy_ip, self.proxy_port)})

    @staticmethod
    def proxy_url(proxy_ip, proxy_port):
        url = 'http://{}:{}'.format(proxy_ip, proxy_port)
        return url

    @staticmethod
    def extract_name(name):
        name = name.split('@')[0]
        return name


    @staticmethod
    def extract_aka(orig_name):
        aka = []
        try:
            names = orig_name.split('@')
            for name in names[1:]:
                aka.append({
                    'aka': name,
                })
            alias_info = json.dumps({'info': aka})
        except UnboundLocalError:
            alias_info = json.dumps({'info': None})
        return alias_info
