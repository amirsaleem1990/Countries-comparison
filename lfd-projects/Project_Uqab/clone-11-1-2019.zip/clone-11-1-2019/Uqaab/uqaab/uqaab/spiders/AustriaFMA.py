##Author: Shahzaib Mumtaz
## Created at: 8- Jan - 2019

import scrapy
import time
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider
from uqaab.spiders.utils.base_customized_spiders import CATEGORY_OPTIONS

class FMAAustriaScraper(UqaabBaseSpider):
    name = 'austria_fma_scraper'
    start_urls = ['https://www.fma.gv.at/en/search-company-database/?cname=&place=&bic=&category=&per_page=100&submitted=1']

    def structure_valid(self,response):
        soup = BeautifulSoup(response.body,'html.parser')
        table = soup.find('div',{'class':'company-query-result-wrap'}).findAll('div',{'class':'company-details-wrap'})
        return len(table) > 0

    def extact_data(self, response):
        thisdict = {}
        soup = BeautifulSoup(response.body, 'html.parser')
        table = soup.find('div',{'class':'company-query-result-wrap'}).findAll('div',{'class':'company-details-wrap'})
        data_tables = ['Category:','Address:','Contact:','Email:','Web:','Phone:','Legal Identifiers:','Commercial register number:']

        for row in table:
            name = row.find('h3').find('span',{'class':'sr-only'}).get_text().strip()
            details = row.find('div',{'class':'company-details'}).find('ul').findAll('li', recursive=False)
            
            for row_2 in details:
                label = row_2.find('strong').get_text().strip()
                if label in data_tables:
                    if len(row_2.findAll('li')) > 1:
                        for d in row_2.findAll('li'):
                            data = d.get_text().strip()
                            thisdict[label] = data
                    else:
                        data = row_2.get_text().strip().split(label)[-1]
                        thisdict[label] = data

            yield Entity({
                'name':name,
                'category':CATEGORY_OPTIONS[1],
                'address':thisdict['Address:']
            })

        try:
            next_page = soup.find('li',{'class':'copy next'}).find('a')['href']
        except:
            next_page = None

        if next_page is not None:
            link = 'https://www.fma.gv.at/en/search-company-database/{0}'.format(next_page)
            yield scrapy.Request(link, callback=self.extact_data, errback=self.error_handler)
            