import scrapy
import traceback
from scrapy.http import Request
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider
import dateparser

class SecondcodeSpider(UqaabBaseSpider):
    name = 'sfc_scrapper'
    allowed_domains = ['www.sfc.hk']
    start_urls = ['https://www.sfc.hk/web/EN/regulatory-functions/enforcement/have-you-seen-these-people/people-subject-to-arrest-warrants.html']

    def structure_valid(self, response):
        return 100

    def extact_data(self, response):
        tables = response.xpath('//*[@class="noborders"]')
        rows = tables[0].xpath('//tr')
        for i in range(0, len(rows), 2):
            
            all_info = rows[i].xpath('td//text()').extract()
            for x in all_info:
                n = x.split(':')
                if "Name" in n[0]:
                    Name = n[1]
                elif "Nationality" in n[0]:
                    Nationality = n[1]
                elif "Date of Birth" in n[0]:
                    DOB = n[1]
                    
            #Name = rows[i].xpath('td//text()')[3].extract()

            #Nationality = rows[i].xpath('td//text()')[4].extract()
            #DOB = rows[i].xpath('td//text()')[6].extract()
            yield {
                'name': Name,
                'date_of_birth': DOB,
                'nationality': Nationality
                }
            #i = i
            
        
        pass
