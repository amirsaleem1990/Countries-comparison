import scrapy
import traceback
from scrapy.http import Request
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider

class TerroristExclusionListSpider(UqaabBaseSpider):
    name = "terrorist_exclusion_list"
    allowed_domains = ["https://www.state.gov"]

    start_urls = [
    'https://www.state.gov/j/ct/rls/other/des/123086.htm',
    ]

    ul_path = "///*[@id='centerblock']/ul[3]"

    def structure_valid(self, response):
        return len(response.xpath(self.ul_path).extract()) > 0

    def extact_data(self, response):
        print("                 *******Extracting Terrorist Exclusion List*******")

        ul = response.xpath(self.ul_path)
        lis = ul.xpath('li/text()').extract()
        if len(lis) > 0 and self.structure_valid:
            name = ''
            for li in lis:
                name = li.strip()
                print(name)

                yield Entity({
                    'name': name
                })
        else:
            print('Structure of ' + str(response.url) + ' has been changed. Unable to find required list.')
        
        print("                 *******Finished Extracting Terrorist Exclusion List*******")