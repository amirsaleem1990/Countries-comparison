# -*- coding: utf-8 -*-
from datetime import datetime
import re
import scrapy
import tabula
import io
from uqaab.items import Entity
from uqaab.spiders.utils.base_customized_spiders import UqaabBaseSpider
from uqaab.spiders.utils.base_customized_spiders import CATEGORY_OPTIONS

class KenyaFirms(UqaabBaseSpider):
    name = 'kenya_firms_spider'
    start_urls = ['http://www.ppoa.go.ke/images/downloads/boraqs-registered-firms/LIST%20OF%20DEBARRED%20FIRMS%20_1_.pdf']

    def structure_valid(self, response):
        return True

    def extact_data(self, response):

        url = 'http://www.ppoa.go.ke/images/downloads/boraqs-registered-firms/LIST%20OF%20DEBARRED%20FIRMS%20_1_.pdf'   

        kenya = tabula.read_pdf(url, encoding="latin1", lattice=True, pandas_options={"skiprows":1})
        print("==========================")
        print(kenya.shape)
        cols = ["CASE_NO", "FIRM_NAME_REGISTRATION_NO", "ZIP_CODE", "CITY", "INELG_FROM", "INELG_TO", "REMARKS", "PROP", "SIGN" ]
        kenya.columns = cols
        kenya = kenya.replace("\r", " ", regex=True)

        for index, row in kenya.iterrows():

            name = self.extract_name(row["PROP"], row["SIGN"])
            organization = row["FIRM_NAME_REGISTRATION_NO"]
            zip_code = row["ZIP_CODE"]
            city = row["CITY"]
            inclusion_date = self.extractDate(row["INELG_FROM"])
            exclusion_date = self.extractDate(row["INELG_TO"])
            remarks = row["REMARKS"]

            yield Entity({
                "name" : name,
                "remarks": remarks,
                "address" : city,
                "organization" : organization,
                "inclusion_date" : inclusion_date,
                "exclusion_date" : exclusion_date,
                "category": CATEGORY_OPTIONS[1]
            })

    @staticmethod
    def extract_name(prop, sign):
        try:

            prop = prop.replace(".", "").replace("-", "").replace(";", "").replace(",", "")
            sign = sign.replace(".", "").replace("-", "").replace(";", "")

            prop = re.sub(r'[2-9+]', ' ', prop).replace("1","").replace(",", "")
            sign = re.sub(r'[2-9+]', ' ', sign).replace("1","")
            
            names = ' '.join([prop, sign])

            return names

        except Exception:
            return None

            
    @staticmethod
    def extractDate(entity_date):
        try:
            return datetime.strptime(entity_date, "%d.%m.%Y")
        except ValueError:
            return None





