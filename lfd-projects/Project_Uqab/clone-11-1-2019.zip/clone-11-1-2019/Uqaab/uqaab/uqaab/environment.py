import os
from decouple import Config, RepositoryEnv

config = Config(RepositoryEnv('D:\\HBL\\Uqaab\\uqaab\\.env'))