import os
from decouple import Config, RepositoryEnv

config = Config(RepositoryEnv('/home/huzaifa/projects/sanctions-scraping/project/uqaab/.env'))
