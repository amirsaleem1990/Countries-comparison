import os
import time
import shutil
import requests
import datetime
import subprocess
import sqlalchemy as sa

from environment import config
from emailer import send_summary_email
from loggers import create_logging_file
from change_detection import get_sublist_ids_of_changed_lists

CONNECTION_STRING = config('SA_CONNECTION_STRING')

logging = create_logging_file()


class ScheduleSpiders():

    PROJECT_NAME = 'uqaab'
    PROJECT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'uqaab')
    SCRAPYD_SERVER_URL = config('SCRAPYD_URL')
    HEALTHCHECKS_SCRAPPINGEND_URL = config('HEALTHCHECKS_SCRAPPINGEND_URL')
    HEALTHCHECKS_SCRAPPINGSTART_URL = config('HEALTHCHECKS_SCRAPPINGSTART_URL')
    HEALTHCHECKS_CHANGEDETECTIONEND_URL = config('HEALTHCHECKS_CHANGEDETECTIONEND_URL')

    def __init__(self):
        self.engine = sa.create_engine(CONNECTION_STRING)
        self.connection = self.engine.connect()
        self.list_ids = []
        self.start_time = datetime.datetime.now()

    def __call__(self):
        self.delete_previous_eggs()
        self.deploy_project()
        self.notify_healthchecks(self.HEALTHCHECKS_SCRAPPINGSTART_URL)
        self.clear_table('tbl_entities')
        self.perform_scheduling()
        self.wait_for_scrapyd_jobs_completion()
        self.wait_for_records_insertion_completion()
        self.notify_healthchecks(self.HEALTHCHECKS_SCRAPPINGEND_URL)
        self.populate_name_and_initials()
        self.close_connection()

        sublist_ids = get_sublist_ids_of_changed_lists(self.list_ids)
        self.notify_healthchecks(self.HEALTHCHECKS_CHANGEDETECTIONEND_URL)
        self.move_data_to_app_db()
        if sublist_ids:
            send_summary_email(sublist_ids, self.start_time)

    def delete_previous_eggs(self):
        logging.info("deleting previous eggs")
        eggs_folder = os.path.join(self.PROJECT_DIR, 'eggs')
        shutil.rmtree(eggs_folder, ignore_errors=True)

    def deploy_project(self):
        logging.info("deploying scrapyd project")
        subprocess.Popen('scrapyd-deploy', cwd=self.PROJECT_DIR)
        time.sleep(30)

    def clear_table(self, table_name):
        logging.info("deleting from the tables")
        DELETE_QUERY = "DELETE FROM {0}".format(table_name)
        self.connection.execute(DELETE_QUERY)

    def perform_scheduling(self):
        QUERY = "SELECT FileName, ListID FROM tbl_watchlist WHERE IsEnabled = ?;"
        enabled_spiders = self.connection.execute(QUERY, (1,)).fetchall()

        logging.info("setting up scrapyd, sending request for scheduling scrapper")
        for spider in enabled_spiders:
            subprocess.Popen(['scrapyd-client', 'schedule', '-p', self.PROJECT_NAME, spider[0], '--arg',
                              'list_id={0}'.format(spider[1])], cwd=self.PROJECT_DIR)
            self.list_ids.append(spider[1])
            time.sleep(2)

    def close_connection(self):
        self.connection.close()
        self.engine.dispose()

    def wait_for_scrapyd_jobs_completion(self):
        jobs_url = '{0}listjobs.json?project={1}'.format(
            self.SCRAPYD_SERVER_URL,
            self.PROJECT_NAME)
        while True:
            req = requests.get(jobs_url)
            response = req.json()
            logging.info("running " + str(response["running"][::-1]))
            logging.info("finished " + str(response["finished"][::-1][:4]))
            if len(response['pending']) == 0 and len(response['running']) == 0:
                return
            time.sleep(5)

    def wait_for_records_insertion_completion(self):
        COUNT_QUERY = "SELECT COUNT(*) from tbl_entities"
        old_count = 0
        got_same_count = 0
        while got_same_count < 5:
            new_count = self.connection.execute(COUNT_QUERY).fetchone()[0]
            if new_count == old_count:
                got_same_count += 1
            old_count = new_count
            time.sleep(5)

    def populate_name_and_initials(self):
        logging.info("populating name and initials")
        cursor = self.engine.raw_connection().cursor()
        cursor.execute("exec cleanNameInsertInitials")
        cursor.commit()

    def notify_healthchecks(self, health_check_url):
        for i in range(10):
            try:
                req = requests.get(health_check_url)
                if req.status_code == 200:
                    logging.info("notifying health check success " + str(health_check_url))
                    return
                time.sleep(5)
            except:
                pass

    def move_data_to_app_db(self):
        start_time_str = str(self.start_time)
        shortened_date_time = start_time_str[0:start_time_str.index('.')]
        db_engine = sa.create_engine(CONNECTION_STRING)
        cursor = db_engine.raw_connection().cursor()
        logging.info("Moving data to application DB")
        print("exec TransportDataToAppDB '{}'".format(shortened_date_time))
        cursor.execute("exec TransportDataToAppDB '{}'".format(shortened_date_time))
        logging.info("Successfully moved data to application DB")
        cursor.commit()
        db_engine.dispose()
            

scheduler = ScheduleSpiders()
scheduler()

